<!DOCTYPE html>
<html>
    <head>
        <title>Lewis Nathaniel</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css">
        
    </head>

    <body>

        <navbar>

            <div class="profil">
                <img class="entete" src="assets/images/lewis.png">
                <div class="nom">
                    <h3> Lewis <br>Nathaniel</h3>
                    <p>UI UX Designer</p>
                </div>   
            </div>

            <div class="menu">
    <?php session_start(); ?>
    <a class="nav" href="#projet" onclick="toggleDropdown(event)">PROJETS</a>
    <?php if (isset($_SESSION['user_id'])): ?>
        <div id="dropdown-menu" class="dropdown-menu">
            <a href="ajouter_projet.php">Ajouter un Projet</a>
            <a href="ajouter_article.php">Ajouter un Article</a>
        </div>
    <?php endif; ?>
    <a class="nav" href="#apropos">A PROPOS</a>
    <a class="nav" href="#blog">BLOG</a>
    <?php if (isset($_SESSION['user_id'])): ?>
        <a class="nav" href="logout.php">DÉCONNEXION</a>
    <?php else: ?>
        <a class="nav" href="connexion.php">CONNEXION</a>
    <?php endif; ?>
    <a class="contacte" onclick="togglePopup()" href="#">CONTACT</a>
</div>

<style>
/* Style du menu */
.menu {
    position: relative;
}

/* Menu déroulant caché par défaut */
.dropdown-menu {
    display: none;
    position: absolute;
    top: 100%; /* Juste en dessous de "PROJETS" */
    left: 0;
    background-color: #ffffff;
    border: 1px solid #ccc;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 10px;
    z-index: 1000;
}

/* Style des liens dans le menu déroulant */
.dropdown-menu a {
    display: block;
    padding: 10px;
    text-decoration: none;
    color: #333;
}

.dropdown-menu a:hover {
    background-color: #f0f0f0;
}
</style>

<script>
// Fonction pour afficher/masquer le menu déroulant
function toggleDropdown(event) {
    const menu = document.getElementById('dropdown-menu');

    // Si le menu est déjà affiché, le masquer
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        menu.style.display = 'block';
    }

    // Permettre au clic de continuer son comportement par défaut
    // uniquement si le menu n'est pas visible
    if (menu.style.display === 'block') {
        event.preventDefault(); // Bloque le défilement vers l'ancre
    }
}


// Fermer le menu déroulant si on clique ailleurs sur la page
document.addEventListener('click', function(event) {
    const menu = document.getElementById('dropdown-menu');
    const isClickInside = menu.contains(event.target) || event.target.matches('.nav[href="#projet"]');
    if (!isClickInside) {
        menu.style.display = 'none';
    }
});
</script>


        </navbar>




        <section1>

            <div class="presentation">

                <p id="t1">Hello, je suis...</p>
                <h1 id="t2">Lewis Nathaniel</h1>
                <h1 id="t3">UI & UX</h1>

                <div class="link">
                    <img src="https://1000logos.net/wp-content/uploads/2020/11/Behance-Logo-2020.jpg" alt="Logo de Behance" width="50" height="50">
                    <img src="https://cdn.freebiesupply.com/logos/large/2x/dribbble-5-logo-png-transparent.png" width="50" height="50">
                    <img src="https://1000logos.net/wp-content/uploads/2020/11/Behance-Logo-2020.jpg" alt="Logo de Behance" width="50" height="50">
                    <img src="https://cdn.freebiesupply.com/logos/large/2x/dribbble-5-logo-png-transparent.png" width="50" height="50">
                    <img src="https://1000logos.net/wp-content/uploads/2020/11/Behance-Logo-2020.jpg" alt="Logo de Behance" width="50" height="50">
                    <img src="https://cdn.freebiesupply.com/logos/large/2x/dribbble-5-logo-png-transparent.png" width="50" height="50">
                </div>


                <a class="contact" onclick="togglePopup()" href="#">CONTACT</a>
                <div id="popup-overlay">
                
                    <div class="popup-content">
                        <div>
                        <h1>CONTACT</h1>
                        <h2>APPELEZ-MOI OU ENVOYEZ-MOI UN MAIL</h2>
                        <div class="information">
                        <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877z"/>
                          </svg> 01 02 03 04 05</p>
                          <p><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16">
                            <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414zM0 4.697v7.104l5.803-3.558zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586zm3.436-.586L16 11.801V4.697z"/>
                          </svg> designer@ui43.com</p>
                          </div>

                          <form>
                          <label for="name">Adresse e-mail</label>
                          <input type="text" id="name"  name="user_name">

                          <label for="bio">Contenu</label>
                        <textarea id="bio"  name="user_bio"></textarea>

                          </form>
                          
                        <a href="#" class="contact">ENVOYER</a>
                        </div>
                        <div>
                            <img src="assets/images/popup-1.jpg">
                        </div>


                        <a href="javascript:void(0)" onclick="togglePopup()" class="popup-exit"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293z"/>
                          </svg></a>
                    </div>

                    
                </div>
                

            </div>

            <div class="illustration">
                <img src ="assets/images/undraw_innovative_b409.svg" width="659px" height="487px">
            </div>

        </section1>

        <sectionprojet id="projet">

            <div class="filtre">
        
                    <a href="#">Tous</a>
                    <a id="togg1" href="#">Mobile</button>
                    <a href="#">Web</a>
                    <a href="#">Interaction</a>
        
            </div>
        
            <div class="projets">
        
                        <div class="projet">
                            <img src="assets/images/projects/App-Screens-Perspective-MockUp-full.jpg">
                            <div class="categorie">
                                <p>Web / Mobile</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 1</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2018</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <div id="d1">
                        <div class="projet">
                            <img src="assets/images/projects/sample_4.jpg">
                            <div class="categorie">
                                <p>Web</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 4</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2021</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        
        
                        <div class="projet">
                            <img src="assets/images/projects/sample_5.jpg">
                            <div class="categorie">
                                <p>Mobile</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 7</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2020</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <div id="d1">
                        <div class="projet">
                            <img src="assets/images/projects/sample_2.jpg">
                            <div class="categorie">
                                <p>Interaction</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 2</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2018</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
        
                        <div class="projet">
                            <img src="assets/images/projects/sample_7.jpg">
                            <div class="categorie">
                                <p>Mobile / Interaction</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 5</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2022</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <div class="projet">
                            <img src="assets/images/projects/Rectangle 405.jpg">
                            <div class="categorie">
                                <p>Web / Mobile / Interaction</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 8</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2022</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
        
                        <div id="d1">
                        <div class="projet">
                            <img src="assets/images/projects/sample_6.jpg">
                            <div class="categorie">
                                <p>Web</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 3</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2018</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
        
                        <div id="d1">
                        <div class="projet">
                            <img src="assets/images/projects/sample_1.jpg">
                            <div class="categorie">
                                <p>Interaction</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 6</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2018</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
        
                        <div id="d1">
                        <div class="projet">
                            <img src="assets/images/projects/cover_photo.jpg">
                            <div class="categorie">
                                <p>Interaction</p>
                                <div class="infos">
                                    <div class="titre">
                                        <h1>PROJET 9</h1>
                                    </div>
                                    <div class="date">
                                        <h1>2019</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
        
        </sectionprojet>

        <sectionapropos id="apropos">
            <div class="image">
                <img src="assets/images/undraw_Designer_by46.svg" width="685px" height="500px">
            </div>
        
            <div class="apropos">
                <h1>A PROPOS...</h1>
        
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                    Maecenas pellentesque eu enim eget luctus. Sed augue felis, 
                    facilisis et elementum vitae, aliquam sit amet ante. Sed iaculis 
                    eros sem, elementum consequat est consequat eu. Quisque 
                    aliquet a ipsum nec tincidunt. Nulla vitae rhoncus leo. Praesent 
                    dui sapien, bibendum quis tempus dictum, auctor ac dui. 
                    Vestibulum ante ipsum primis in faucibus orci luctus et ultrices 
                    posuere cubilia Curae; Donec at mauris porta, ullamcorper sem 
                    quis, lobortis sem. Donec sit amet aliquet dui, at varius est. 
                    Phasellus porttitor finibus neque vel vehicula.</p>
        
                <a class="contact" href="#">CONTACT</a>
            </div>
        </sectionapropos>
        

        <sectiontemoignage>

            <div class="banniere">

                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pellentesque eu enim eget luctus. Sed augue felis, 
                    facilisis et elementum vitae, aliquam sit amet ante. Sed iaculis eros sem, elementum consequat est consequat eu. Quisque 
                    aliquet a ipsum nec tincidunt. Nulla vitae rhoncus leo. Praesent dui sapien, bibendum quis tempus dictum.</p>
                
                <div class="profilauteur">
                    <img src="assets/images/lena.jpg" width="125px" height="125px">
                </div>

                <div class="auteur">
                    <h1> Lena M. Brooks </h1>
                    <h2>Marketing House</h2>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                      </svg> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                      </svg> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                      </svg> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                      </svg> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-half" viewBox="0 0 16 16">
                        <path d="M5.354 5.119 7.538.792A.52.52 0 0 1 8 .5c.183 0 .366.097.465.292l2.184 4.327 4.898.696A.54.54 0 0 1 16 6.32a.55.55 0 0 1-.17.445l-3.523 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256a.5.5 0 0 1-.146.05c-.342.06-.668-.254-.6-.642l.83-4.73L.173 6.765a.55.55 0 0 1-.172-.403.6.6 0 0 1 .085-.302.51.51 0 0 1 .37-.245zM8 12.027a.5.5 0 0 1 .232.056l3.686 1.894-.694-3.957a.56.56 0 0 1 .162-.505l2.907-2.77-4.052-.576a.53.53 0 0 1-.393-.288L8.001 2.223 8 2.226z"/>
                      </svg>
                </div>

            </div>
        

            <div class="auteurtemoignage">


            </div>



        </sectiontemoignage>


        <sectionblog id="blog">

            <div class="title">

                <h1>MON BLOG</h1>
                <p>Mes avis sur les dernières tendances du Web</p>

            </div>

            <div class="articles">
                <div class="article">
                    <img src="assets/images/blog/airbnb-2384737_1920.jpg">
                    <h1>TOP 10 TRENDS FOR 2023</h1>
                    <p> Lorem ipsum dolor sit amet, consectetur 
                        adipiscing elit. Maecenas pellentesque eu enim 
                        eget luctus. Sed augue felis, facilisis et 
                        elementum vitae, aliquam sit amet ante. Sed 
                        iaculis eros sem, elementum consequat.</p>
                    <div class="boutonlire">
                    <a class="lire" href="#">LIRE</a>
                    </div>
                </div>

                <div class="article">
                    <img src="assets/images/blog/office-820390_1920.jpg">
                    <h1>WEBSITE INSPIRATION</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur 
                    adipiscing elit. Maecenas pellentesque eu enim 
                    eget luctus. Sed augue felis, facilisis et 
                    elementum vitae, aliquam sit amet ante. Sed 
                    iaculis eros sem, elementum consequat.</p>

                    <a class="lire" href="#">LIRE</a>
                </div>

                <div class="article">
                    <img src="assets/images/blog/technology-3164715_1920.jpg">
                    <h1>CHANGES IN SOCIAL MEDIA</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur 
                    adipiscing elit. Maecenas pellentesque eu enim 
                    eget luctus. Sed augue felis, facilisis et 
                    elementum vitae, aliquam sit amet ante. Sed 
                    iaculis eros sem, elementum consequat.</p>

                    <a class="lire" href="#">LIRE</a>
                </div>
            </div>


        </sectionblog>

        




        <div class="footer-basic">
    <footer>
        <p>© 2018 UI43 - Free Templates</p>
        <div class="social-links">
            <a href="https://www.instagram.com/" target="_blank">
                <img src="assets/images/instagram.png" alt="Instagram">
            </a>
            <a href="https://www.facebook.com/" target="_blank">
                <img src="assets/images/facebook.png" alt="Facebook">
            </a>
            <a href="https://twitter.com/" target="_blank">
                <img src="assets/images/twitter.png" alt="Twitter">
            </a>
            <a href="https://www.linkedin.com/" target="_blank" class="linkedin">
                <img src="assets/images/linkedin.png" alt="LinkedIn">
            </a>
        </div>
    </footer>
</div>



        <script>

let togg1 = document.getElementById("togg1");
let togg2 = document.getElementById("togg2");
let d1 = document.getElementById("d1");
let d2 = document.getElementById("d2");
togg1.addEventListener("click", () => {
if(getComputedStyle(d1).display != "none"){
d1.style.display = "none";
} else {
d1.style.display = "block";
}
})

function togg(){
if(getComputedStyle(d2).display != "none"){
d2.style.display = "none";
} else {
d2.style.display = "block";
}
};
togg2.onclick = togg;

</script>



    <script src="java.js"></script>
    </body>
</html>