function togglePopup() {
    let popup = document.querySelector("#popup-overlay");
    popup.classList.toggle("open")
}